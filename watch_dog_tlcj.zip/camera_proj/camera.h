#define CAMERA_MODEL_AI_THINKER
#include "esp_camera.h"
#include "Arduino.h"
#include "RTClib.h"
#include "secrets.h"
#include <WiFi.h>
#include "logger.h"
#include "constants.h"


/*
  voltage test function
*/
void voltageTest();
 
/*
   led operating function
*/
void measureLight(int idx);

/*
   configuration function
*/
void configInitCam();


/*
   SD card initialising
*/
void initMicroSDCard();

/*
   wifi function
*/
void takeSavePhoto(int indicator,int idx);

/*
   wifi function
*/
void wifiCon();
