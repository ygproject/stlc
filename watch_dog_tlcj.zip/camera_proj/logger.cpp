#include "logger.h"
#include "camera.h"

int idx = 0;
int flag1 = 0;

void iupdate(const char * path)
{
	File file = SD_MMC.open(path, FILE_WRITE);
	if(!file)
	{
		Serial.println("There was an error opening the file for writing");
	}
	else if(file.print(idx))
	{
		Serial.println("File was written");;
	}
	else 
	{
		Serial.println("File write failed");
	}
	file.close();
	Serial.println(idx);
}

void iread(const char * path)
{
	File file = SD_MMC.open(path, FILE_READ);
	if(!file)
	{
        Serial.println("No file");
		idx = 0;
		flag1 = 0;
    }
    Serial.println("File Content:");
    while(file.available())
    {
      idx = file.parseInt();
      Serial.println(idx);
    }
    file.close();
}

void logger()
{
  String dataMessage= ("log entry_" + String(idx)+ " \r\n");
  digitalWrite(4, LOW);
  
  //add maybe struct for errors.
  String emailMessage = "life sign for boot number: " + String(idx);

  wifiCon();
  sendEmail(emailMessage,(idx));
  WiFi.mode( WIFI_MODE_NULL );
}
