//# ignore source code files
//source/**/*secrets.h

//wifi
#define WIFI_NAME "POCO F3"
#define WIFI_PASSWORD "arx160CQB"  

//smtp server
#define SENDER_ACCOUNT "esp32tlc@gmail.com"
#define SENDER_PASS    "QCqrvz9))"
#define SMTP_SRV     "smtp.gmail.com"
#define SMTP_PORT    465
#define EMAIL_SUB    "Subject"
#define RECIPIENT1    "yoav.eshed@mail.huji.ac.il"
#define RECIPIENT2    ""
